## Live translator by speech,
Hi,

I'm happy to share this app here, bc I made this app for my need :D Iill use it almost everyday :D

I am trying to improve my English knowledge and I like to read books in English. Sometimes I read PDFs or e-books with my iPad or computer, but it's a waste of time when I need to check the meaning of a word (I don't know) in the dictionary.

So I thought I could make a program for it. If I come across a word that sounds unfamiliar to me while reading a book on my iPad, I can press a key on the keyboard (in my case "0") and say the word and see the Turkish translation of the word on the screen. 
- Actually I could add reading feature for it also, but I cant be sure if my pronunciation is True or not. So I wanna see the english and the turkish versions of the words on the screen.

I spend some time today on this and here it is.
![image0](https://user-images.githubusercontent.com/70684994/156655272-057999a9-31be-482b-83cd-3e05e6918fd3.png)

![image](https://user-images.githubusercontent.com/70684994/156646703-07fb9251-0d96-4836-a8fc-c69c5f2f4a1c.png)
